# Custom Enchantments

## Information

The plugin's main page: http://dev.bukkit.org/bukkit-plugins/custom-enchantments/

This project was not originally intended to be public, 
if you still want to take a look into the code and or contribute to the project, 
feel free to do so.

## Dependencies

Custom Enchantments requires the following libraries:

* Bukkit / Spigot, independent of the version
* Vault (http://dev.bukkit.org/bukkit-plugins/vault)
* Worldedit (http://dev.bukkit.org/bukkit-plugins/worldedit/)
* WorldGuard, with a Version below 6.0 (http://dev.bukkit.org/bukkit-plugins/worldguard)
